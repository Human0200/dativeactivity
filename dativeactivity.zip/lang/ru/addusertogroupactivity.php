<?php
     $MESS ['BPAG_USER_ID_REQUIRED'] = "ID обязательны для заполнения.";
     $MESS ['BPAG_GROUP_ID_REQUIRED'] = "ID обязательны для заполнения.";
     $MESS ['BPAG_USER_ADDED_TO_GROUP'] = "Пользователь успешно добавлен в группу.";
     $MESS ['BPAG_ADD_USER_ERROR'] = "Ошибка при добавлении пользователя в группу.";
     $MESS ['BPACL_CONTACT_NOT_FOUND'] = "Контакт с указанным номером телефона не найден.";
     ?>