<?php
     $MESS ['BPAG_DESCR_NAME'] = "Привязка пользователя к группе";
     $MESS ['BPAG_DESCR_DESCR'] = "Привязывает пользователя к группе";
     $MESS ['BPAG_USER_ID'] = "ID пользователя";
     $MESS ['BPAG_GROUP_ID'] = "ID группы";
     $MESS ['BPAG_RESULT'] = "Результат";
     ?>