<?php
//ппп
     $MESS ['BPAG_USER_ID_LABEL'] = "ID пользователя";
     $MESS ['BPAG_GROUP_ID_LABEL'] = "ID группы";
     $MESS ['BPAG_GROUP_OWNER_ID_LABEL'] = "ID владельца группы";
?>